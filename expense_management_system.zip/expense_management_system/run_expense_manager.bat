@echo off
cd /d "%~dp0"
py expense_manager.py
if errorlevel 1 (
    echo.
    echo The application could not start. Make sure Python and Tkinter are installed.
    pause
)
