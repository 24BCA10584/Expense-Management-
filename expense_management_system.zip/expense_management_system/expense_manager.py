"""Expense Management System

A local desktop expense tracker built with Python's Tkinter and SQLite.
No third-party packages are required.
"""

from __future__ import annotations

import csv
import sqlite3
import tkinter as tk
from datetime import date, datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk


APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "expense_manager.db"
CURRENCY = "₹"

CATEGORIES = [
    "Food", "Transport", "Shopping", "Bills", "Health",
    "Education", "Entertainment", "Personal", "Other"
]
PAYMENT_METHODS = ["Cash", "UPI", "Card", "Bank Transfer", "Other"]


def money(value: float) -> str:
    return f"{CURRENCY}{value:,.2f}"


def current_month() -> str:
    return date.today().strftime("%Y-%m")


class ExpenseDatabase:
    """Handles all SQLite operations for expenses and budgets."""

    def __init__(self, db_path: Path = DB_PATH):
        self.connection = sqlite3.connect(db_path)
        self.connection.row_factory = sqlite3.Row
        self.create_tables()

    def create_tables(self) -> None:
        with self.connection:
            self.connection.execute(
                """CREATE TABLE IF NOT EXISTS expenses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    expense_date TEXT NOT NULL,
                    category TEXT NOT NULL,
                    description TEXT NOT NULL,
                    amount REAL NOT NULL CHECK(amount > 0),
                    payment_method TEXT NOT NULL
                )"""
            )
            self.connection.execute(
                """CREATE TABLE IF NOT EXISTS budgets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    month TEXT NOT NULL,
                    category TEXT NOT NULL,
                    amount REAL NOT NULL CHECK(amount >= 0),
                    UNIQUE(month, category)
                )"""
            )

    def add_expense(self, values: tuple) -> None:
        with self.connection:
            self.connection.execute(
                """INSERT INTO expenses
                   (expense_date, category, description, amount, payment_method)
                   VALUES (?, ?, ?, ?, ?)""",
                values,
            )

    def update_expense(self, expense_id: int, values: tuple) -> None:
        with self.connection:
            self.connection.execute(
                """UPDATE expenses
                   SET expense_date=?, category=?, description=?, amount=?, payment_method=?
                   WHERE id=?""",
                (*values, expense_id),
            )

    def delete_expense(self, expense_id: int) -> None:
        with self.connection:
            self.connection.execute("DELETE FROM expenses WHERE id=?", (expense_id,))

    def get_expense(self, expense_id: int):
        return self.connection.execute(
            "SELECT * FROM expenses WHERE id=?", (expense_id,)
        ).fetchone()

    def get_expenses(self, month: str = "", category: str = "", search: str = ""):
        query = "SELECT * FROM expenses WHERE 1=1"
        parameters = []

        if month:
            query += " AND substr(expense_date, 1, 7)=?"
            parameters.append(month)
        if category and category != "All Categories":
            query += " AND category=?"
            parameters.append(category)
        if search:
            query += " AND (description LIKE ? OR category LIKE ? OR payment_method LIKE ?)"
            term = f"%{search}%"
            parameters.extend([term, term, term])

        query += " ORDER BY expense_date DESC, id DESC"
        return self.connection.execute(query, parameters).fetchall()

    def get_month_total(self, month: str) -> float:
        row = self.connection.execute(
            "SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE substr(expense_date, 1, 7)=?",
            (month,),
        ).fetchone()
        return float(row["total"])

    def get_month_count(self, month: str) -> int:
        row = self.connection.execute(
            "SELECT COUNT(*) AS total FROM expenses WHERE substr(expense_date, 1, 7)=?",
            (month,),
        ).fetchone()
        return int(row["total"])

    def get_category_totals(self, month: str):
        return self.connection.execute(
            """SELECT category, SUM(amount) AS total
               FROM expenses WHERE substr(expense_date, 1, 7)=?
               GROUP BY category ORDER BY total DESC""",
            (month,),
        ).fetchall()

    def get_recent_expenses(self, limit: int = 6):
        return self.connection.execute(
            "SELECT * FROM expenses ORDER BY expense_date DESC, id DESC LIMIT ?",
            (limit,),
        ).fetchall()

    def get_monthly_trend(self, count: int = 6):
        months = []
        today = date.today()
        year, month = today.year, today.month
        for _ in range(count):
            months.append(f"{year:04d}-{month:02d}")
            month -= 1
            if month == 0:
                month = 12
                year -= 1
        months.reverse()

        values = []
        for month_value in months:
            total = self.get_month_total(month_value)
            label = datetime.strptime(month_value, "%Y-%m").strftime("%b")
            values.append((label, total))
        return values

    def get_budgets(self, month: str):
        return self.connection.execute(
            "SELECT * FROM budgets WHERE month=? ORDER BY category", (month,)
        ).fetchall()

    def get_budget_total(self, month: str) -> float:
        row = self.connection.execute(
            "SELECT COALESCE(SUM(amount), 0) AS total FROM budgets WHERE month=?",
            (month,),
        ).fetchone()
        return float(row["total"])

    def save_budget(self, month: str, category: str, amount: float) -> None:
        with self.connection:
            self.connection.execute(
                """INSERT INTO budgets (month, category, amount) VALUES (?, ?, ?)
                   ON CONFLICT(month, category) DO UPDATE SET amount=excluded.amount""",
                (month, category, amount),
            )

    def delete_budget(self, budget_id: int) -> None:
        with self.connection:
            self.connection.execute("DELETE FROM budgets WHERE id=?", (budget_id,))

    def close(self) -> None:
        self.connection.close()


class ExpenseDialog(tk.Toplevel):
    """Dialog used for adding and editing an expense."""

    def __init__(self, parent, on_save, expense=None):
        super().__init__(parent)
        self.on_save = on_save
        self.expense = expense
        self.title("Edit Expense" if expense else "Add Expense")
        self.geometry("440x470")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self.configure(bg="#f5f7fb")

        self.date_var = tk.StringVar(value=expense["expense_date"] if expense else date.today().isoformat())
        self.category_var = tk.StringVar(value=expense["category"] if expense else CATEGORIES[0])
        self.description_var = tk.StringVar(value=expense["description"] if expense else "")
        self.amount_var = tk.StringVar(value=str(expense["amount"]) if expense else "")
        self.payment_var = tk.StringVar(value=expense["payment_method"] if expense else PAYMENT_METHODS[1])

        body = ttk.Frame(self, padding=24)
        body.pack(fill="both", expand=True)

        heading = "Update expense details" if expense else "Record a new expense"
        ttk.Label(body, text=heading, font=("Segoe UI", 16, "bold")).pack(anchor="w", pady=(0, 18))

        self.add_field(body, "Date (YYYY-MM-DD)", ttk.Entry(body, textvariable=self.date_var))
        self.add_field(body, "Category", ttk.Combobox(body, textvariable=self.category_var, values=CATEGORIES, state="readonly"))
        self.add_field(body, "Description", ttk.Entry(body, textvariable=self.description_var))
        self.add_field(body, "Amount (₹)", ttk.Entry(body, textvariable=self.amount_var))
        self.add_field(body, "Payment method", ttk.Combobox(body, textvariable=self.payment_var, values=PAYMENT_METHODS, state="readonly"))

        buttons = ttk.Frame(body)
        buttons.pack(fill="x", pady=(20, 0))
        ttk.Button(buttons, text="Cancel", command=self.destroy).pack(side="right")
        ttk.Button(buttons, text="Save Expense", style="Accent.TButton", command=self.save).pack(side="right", padx=(0, 8))

    @staticmethod
    def add_field(parent, label, widget):
        ttk.Label(parent, text=label).pack(anchor="w", pady=(0, 4))
        widget.pack(fill="x", ipady=5, pady=(0, 12))

    def save(self):
        expense_date = self.date_var.get().strip()
        description = self.description_var.get().strip()
        try:
            datetime.strptime(expense_date, "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Invalid date", "Enter the date in YYYY-MM-DD format.", parent=self)
            return

        try:
            amount = float(self.amount_var.get().strip())
            if amount <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid amount", "Enter an amount greater than zero.", parent=self)
            return

        if not description:
            messagebox.showerror("Missing description", "Please enter a short description.", parent=self)
            return

        values = (
            expense_date,
            self.category_var.get(),
            description,
            amount,
            self.payment_var.get(),
        )
        self.on_save(values, self.expense["id"] if self.expense else None)
        self.destroy()


class ExpenseManagerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Expense Management System")
        self.root.geometry("1180x780")
        self.root.minsize(1020, 680)
        self.root.configure(bg="#f5f7fb")
        self.db = ExpenseDatabase()

        self.setup_styles()
        self.build_header()
        self.build_tabs()
        self.refresh_all()
        self.root.protocol("WM_DELETE_WINDOW", self.close_app)

    def setup_styles(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("TFrame", background="#f5f7fb")
        style.configure("TLabel", background="#f5f7fb", foreground="#25324a", font=("Segoe UI", 10))
        style.configure("TButton", font=("Segoe UI", 9), padding=(10, 7))
        style.configure("Accent.TButton", background="#315efb", foreground="white", borderwidth=0)
        style.map("Accent.TButton", background=[("active", "#244bd0")])
        style.configure("Treeview", font=("Segoe UI", 9), rowheight=30, background="white", fieldbackground="white")
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#e9eef8", foreground="#25324a", padding=8)
        style.map("Treeview", background=[("selected", "#dce6ff")], foreground=[("selected", "#17264a")])
        style.configure("TNotebook", background="#f5f7fb", borderwidth=0)
        style.configure("TNotebook.Tab", font=("Segoe UI", 10, "bold"), padding=(18, 10))
        style.configure("Horizontal.TProgressbar", troughcolor="#e7ebf3", background="#315efb", thickness=9)

    def build_header(self):
        header = tk.Frame(self.root, bg="#17233d", height=92)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="Expense Management System", bg="#17233d", fg="white",
                 font=("Segoe UI", 21, "bold")).pack(anchor="w", padx=28, pady=(17, 2))
        tk.Label(header, text="Track spending, manage monthly budgets and understand where your money goes.",
                 bg="#17233d", fg="#c7d2e8", font=("Segoe UI", 10)).pack(anchor="w", padx=30)

    def build_tabs(self):
        container = ttk.Frame(self.root, padding=(22, 16, 22, 18))
        container.pack(fill="both", expand=True)
        self.notebook = ttk.Notebook(container)
        self.notebook.pack(fill="both", expand=True)

        self.dashboard_tab = ttk.Frame(self.notebook, padding=18)
        self.transactions_tab = ttk.Frame(self.notebook, padding=18)
        self.budgets_tab = ttk.Frame(self.notebook, padding=18)
        self.notebook.add(self.dashboard_tab, text="Dashboard")
        self.notebook.add(self.transactions_tab, text="Transactions")
        self.notebook.add(self.budgets_tab, text="Monthly Budgets")

        self.build_dashboard()
        self.build_transactions()
        self.build_budgets()

    def build_dashboard(self):
        top = ttk.Frame(self.dashboard_tab)
        top.pack(fill="x", pady=(0, 16))
        ttk.Label(top, text="Overview", font=("Segoe UI", 17, "bold")).pack(side="left")
        self.dashboard_month_label = ttk.Label(top, text="", foreground="#66738a")
        self.dashboard_month_label.pack(side="right", pady=6)

        cards = ttk.Frame(self.dashboard_tab)
        cards.pack(fill="x", pady=(0, 17))
        self.card_values = {}
        card_specs = [
            ("spent", "Spent this month", "#315efb"),
            ("budget", "Monthly budget", "#16856b"),
            ("remaining", "Budget remaining", "#a15c17"),
            ("count", "Transactions", "#6654b8"),
        ]
        for index, (key, title, accent) in enumerate(card_specs):
            card = tk.Frame(cards, bg="white", highlightbackground="#e5eaf2", highlightthickness=1)
            card.grid(row=0, column=index, sticky="nsew", padx=(0 if index == 0 else 9, 0))
            cards.columnconfigure(index, weight=1)
            tk.Frame(card, bg=accent, height=4).pack(fill="x")
            tk.Label(card, text=title, bg="white", fg="#68758c", font=("Segoe UI", 9)).pack(anchor="w", padx=15, pady=(12, 4))
            value_label = tk.Label(card, text="—", bg="white", fg="#1c2940", font=("Segoe UI", 18, "bold"))
            value_label.pack(anchor="w", padx=15, pady=(0, 13))
            self.card_values[key] = value_label

        middle = ttk.Frame(self.dashboard_tab)
        middle.pack(fill="both", expand=True, pady=(0, 14))
        middle.columnconfigure(0, weight=1)
        middle.columnconfigure(1, weight=1)
        middle.rowconfigure(0, weight=1)

        category_card = tk.Frame(middle, bg="white", highlightbackground="#e5eaf2", highlightthickness=1)
        category_card.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        tk.Label(category_card, text="Spending by category", bg="white", fg="#1c2940",
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=16, pady=(14, 5))
        self.category_area = tk.Frame(category_card, bg="white")
        self.category_area.pack(fill="both", expand=True, padx=16, pady=(8, 14))

        trend_card = tk.Frame(middle, bg="white", highlightbackground="#e5eaf2", highlightthickness=1)
        trend_card.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        tk.Label(trend_card, text="Six-month spending trend", bg="white", fg="#1c2940",
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=16, pady=(14, 5))
        self.trend_canvas = tk.Canvas(trend_card, bg="white", highlightthickness=0, height=220)
        self.trend_canvas.pack(fill="both", expand=True, padx=12, pady=(0, 10))

        recent_card = tk.Frame(self.dashboard_tab, bg="white", highlightbackground="#e5eaf2", highlightthickness=1)
        recent_card.pack(fill="both", expand=False)
        tk.Label(recent_card, text="Recent transactions", bg="white", fg="#1c2940",
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=16, pady=(12, 8))
        columns = ("date", "description", "category", "payment", "amount")
        self.recent_tree = ttk.Treeview(recent_card, columns=columns, show="headings", height=4)
        self.configure_expense_tree(self.recent_tree)
        self.recent_tree.pack(fill="x", padx=12, pady=(0, 12))

    def build_transactions(self):
        toolbar = ttk.Frame(self.transactions_tab)
        toolbar.pack(fill="x", pady=(0, 14))
        ttk.Label(toolbar, text="All transactions", font=("Segoe UI", 17, "bold")).pack(side="left")
        ttk.Button(toolbar, text="＋ Add Expense", style="Accent.TButton", command=self.open_add_dialog).pack(side="right")

        filters = ttk.Frame(self.transactions_tab)
        filters.pack(fill="x", pady=(0, 12))
        ttk.Label(filters, text="Month:").pack(side="left", padx=(0, 6))
        self.filter_month_var = tk.StringVar(value=current_month())
        month_entry = ttk.Entry(filters, textvariable=self.filter_month_var, width=12)
        month_entry.pack(side="left", padx=(0, 14), ipady=4)
        ttk.Label(filters, text="Category:").pack(side="left", padx=(0, 6))
        self.filter_category_var = tk.StringVar(value="All Categories")
        category_filter = ttk.Combobox(filters, textvariable=self.filter_category_var,
                                       values=["All Categories"] + CATEGORIES, state="readonly", width=17)
        category_filter.pack(side="left", padx=(0, 14), ipady=3)
        ttk.Label(filters, text="Search:").pack(side="left", padx=(0, 6))
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(filters, textvariable=self.search_var, width=22)
        search_entry.pack(side="left", padx=(0, 8), ipady=4)
        ttk.Button(filters, text="Apply filters", command=self.refresh_transactions).pack(side="left")
        ttk.Button(filters, text="Clear", command=self.clear_filters).pack(side="left", padx=6)

        actions = ttk.Frame(self.transactions_tab)
        actions.pack(fill="x", pady=(0, 9))
        ttk.Button(actions, text="Edit selected", command=self.edit_selected).pack(side="left")
        ttk.Button(actions, text="Delete selected", command=self.delete_selected).pack(side="left", padx=7)
        ttk.Button(actions, text="Export CSV", command=self.export_csv).pack(side="right")

        table_frame = ttk.Frame(self.transactions_tab)
        table_frame.pack(fill="both", expand=True)
        columns = ("id", "date", "description", "category", "payment", "amount")
        self.transaction_tree = ttk.Treeview(table_frame, columns=columns, show="headings")
        self.configure_expense_tree(self.transaction_tree, include_id=True)
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.transaction_tree.yview)
        self.transaction_tree.configure(yscrollcommand=scrollbar.set)
        self.transaction_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.transaction_tree.bind("<Double-1>", lambda _event: self.edit_selected())

        self.transaction_total_label = ttk.Label(self.transactions_tab, text="", font=("Segoe UI", 10, "bold"))
        self.transaction_total_label.pack(anchor="e", pady=(10, 0))

    def configure_expense_tree(self, tree, include_id=False):
        columns = tree["columns"]
        headings = {
            "id": ("ID", 55), "date": ("Date", 105), "description": ("Description", 280),
            "category": ("Category", 130), "payment": ("Payment method", 145), "amount": ("Amount", 125)
        }
        for column in columns:
            title, width = headings[column]
            tree.heading(column, text=title)
            tree.column(column, width=width, minwidth=55, anchor="w")
        tree.column("amount", anchor="e")
        if not include_id and "id" in columns:
            tree.column("id", width=0, stretch=False)

    def build_budgets(self):
        heading = ttk.Frame(self.budgets_tab)
        heading.pack(fill="x", pady=(0, 14))
        ttk.Label(heading, text="Monthly budgets", font=("Segoe UI", 17, "bold")).pack(side="left")
        ttk.Label(heading, text="Set a spending limit for each category.", foreground="#68758c").pack(side="left", padx=16, pady=7)

        form = tk.Frame(self.budgets_tab, bg="white", highlightbackground="#e5eaf2", highlightthickness=1)
        form.pack(fill="x", pady=(0, 16))
        inner = ttk.Frame(form, padding=18)
        inner.pack(fill="x")
        self.budget_month_var = tk.StringVar(value=current_month())
        self.budget_category_var = tk.StringVar(value=CATEGORIES[0])
        self.budget_amount_var = tk.StringVar()

        ttk.Label(inner, text="Month (YYYY-MM)").grid(row=0, column=0, sticky="w", padx=(0, 10))
        ttk.Entry(inner, textvariable=self.budget_month_var, width=15).grid(row=1, column=0, sticky="w", padx=(0, 18), ipady=5)
        ttk.Label(inner, text="Category").grid(row=0, column=1, sticky="w", padx=(0, 10))
        ttk.Combobox(inner, textvariable=self.budget_category_var, values=CATEGORIES,
                     state="readonly", width=19).grid(row=1, column=1, sticky="w", padx=(0, 18), ipady=3)
        ttk.Label(inner, text="Budget amount (₹)").grid(row=0, column=2, sticky="w", padx=(0, 10))
        ttk.Entry(inner, textvariable=self.budget_amount_var, width=18).grid(row=1, column=2, sticky="w", padx=(0, 18), ipady=5)
        ttk.Button(inner, text="Save budget", style="Accent.TButton", command=self.save_budget).grid(row=1, column=3, padx=(0, 8))
        ttk.Button(inner, text="Load month", command=self.refresh_budgets).grid(row=1, column=4)

        ttk.Label(self.budgets_tab, text="Budget allocations", font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(2, 8))
        table_frame = ttk.Frame(self.budgets_tab)
        table_frame.pack(fill="both", expand=True)
        self.budget_tree = ttk.Treeview(table_frame, columns=("id", "category", "budget", "spent", "remaining"), show="headings")
        budget_headings = {
            "id": ("ID", 55), "category": ("Category", 200), "budget": ("Monthly budget", 180),
            "spent": ("Spent so far", 180), "remaining": ("Remaining", 180)
        }
        for key, (label, width) in budget_headings.items():
            self.budget_tree.heading(key, text=label)
            self.budget_tree.column(key, width=width, anchor="w")
        self.budget_tree.column("id", width=0, stretch=False)
        for key in ("budget", "spent", "remaining"):
            self.budget_tree.column(key, anchor="e")
        self.budget_tree.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.budget_tree.yview)
        self.budget_tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        ttk.Button(self.budgets_tab, text="Delete selected budget", command=self.delete_selected_budget).pack(anchor="e", pady=(10, 0))

    def refresh_all(self):
        self.refresh_dashboard()
        self.refresh_transactions()
        self.refresh_budgets()

    def refresh_dashboard(self):
        month = current_month()
        spent = self.db.get_month_total(month)
        budget = self.db.get_budget_total(month)
        remaining = budget - spent
        self.dashboard_month_label.config(text=datetime.now().strftime("%B %Y"))
        self.card_values["spent"].config(text=money(spent))
        self.card_values["budget"].config(text=money(budget))
        self.card_values["remaining"].config(text=money(remaining), fg="#16856b" if remaining >= 0 else "#c0392b")
        self.card_values["count"].config(text=str(self.db.get_month_count(month)))

        for child in self.category_area.winfo_children():
            child.destroy()
        category_rows = self.db.get_category_totals(month)
        if not category_rows:
            ttk.Label(self.category_area, text="No expenses recorded this month yet.", foreground="#7a879b").pack(anchor="w", pady=12)
        else:
            max_total = max(float(row["total"]) for row in category_rows) or 1
            for row in category_rows[:7]:
                line = tk.Frame(self.category_area, bg="white")
                line.pack(fill="x", pady=5)
                top_line = tk.Frame(line, bg="white")
                top_line.pack(fill="x")
                tk.Label(top_line, text=row["category"], bg="white", fg="#34425c",
                         font=("Segoe UI", 9, "bold")).pack(side="left")
                tk.Label(top_line, text=money(float(row["total"])), bg="white", fg="#34425c",
                         font=("Segoe UI", 9)).pack(side="right")
                track = tk.Canvas(line, height=8, bg="#edf0f6", highlightthickness=0)
                track.pack(fill="x", pady=(5, 0))
                track.update_idletasks()
                width = max(track.winfo_width(), 100)
                track.create_rectangle(0, 0, width * float(row["total"]) / max_total, 8,
                                       fill="#5278f5", outline="")

        for item in self.recent_tree.get_children():
            self.recent_tree.delete(item)
        for row in self.db.get_recent_expenses(5):
            self.recent_tree.insert("", "end", values=(
                row["expense_date"], row["description"], row["category"],
                row["payment_method"], money(float(row["amount"]))
            ))
        self.draw_trend()

    def draw_trend(self):
        canvas = self.trend_canvas
        canvas.delete("all")
        canvas.update_idletasks()
        width = max(canvas.winfo_width(), 360)
        height = max(canvas.winfo_height(), 180)
        values = self.db.get_monthly_trend(6)
        max_value = max((value for _, value in values), default=0) or 1
        left, right, top, bottom = 42, width - 16, 18, height - 35
        canvas.create_line(left, bottom, right, bottom, fill="#d8deea")
        bar_area = right - left
        slot = bar_area / len(values)
        for index, (label, value) in enumerate(values):
            bar_width = min(30, slot * 0.55)
            x1 = left + index * slot + (slot - bar_width) / 2
            bar_height = (bottom - top - 12) * value / max_value
            y1 = bottom - bar_height
            canvas.create_rectangle(x1, y1, x1 + bar_width, bottom, fill="#5278f5", outline="")
            canvas.create_text(x1 + bar_width / 2, bottom + 15, text=label, fill="#68758c", font=("Segoe UI", 8))
            if value > 0:
                canvas.create_text(x1 + bar_width / 2, max(y1 - 9, top), text=f"{value:,.0f}",
                                   fill="#53617a", font=("Segoe UI", 7))
        if all(value == 0 for _, value in values):
            canvas.create_text(width / 2, height / 2, text="Your monthly spending trend will appear here.",
                               fill="#7a879b", font=("Segoe UI", 9))

    def refresh_transactions(self):
        month = self.filter_month_var.get().strip()
        if month:
            try:
                datetime.strptime(month, "%Y-%m")
            except ValueError:
                messagebox.showerror("Invalid month", "Enter the month as YYYY-MM, or leave it blank.", parent=self.root)
                return
        rows = self.db.get_expenses(month, self.filter_category_var.get(), self.search_var.get().strip())
        for item in self.transaction_tree.get_children():
            self.transaction_tree.delete(item)
        total = 0.0
        for row in rows:
            amount = float(row["amount"])
            total += amount
            self.transaction_tree.insert("", "end", values=(
                row["id"], row["expense_date"], row["description"], row["category"],
                row["payment_method"], money(amount)
            ))
        self.transaction_total_label.config(text=f"{len(rows)} transaction(s)   |   Total: {money(total)}")

    def refresh_budgets(self):
        month = self.budget_month_var.get().strip()
        try:
            datetime.strptime(month, "%Y-%m")
        except ValueError:
            messagebox.showerror("Invalid month", "Enter the month as YYYY-MM.", parent=self.root)
            return
        for item in self.budget_tree.get_children():
            self.budget_tree.delete(item)
        spent_by_category = {row["category"]: float(row["total"]) for row in self.db.get_category_totals(month)}
        for row in self.db.get_budgets(month):
            budget = float(row["amount"])
            spent = spent_by_category.get(row["category"], 0.0)
            remaining = budget - spent
            self.budget_tree.insert("", "end", values=(
                row["id"], row["category"], money(budget), money(spent), money(remaining)
            ))

    def open_add_dialog(self):
        ExpenseDialog(self.root, self.save_expense)

    def save_expense(self, values, expense_id=None):
        try:
            if expense_id is None:
                self.db.add_expense(values)
            else:
                self.db.update_expense(expense_id, values)
            self.refresh_all()
        except sqlite3.Error as error:
            messagebox.showerror("Database error", f"The expense could not be saved.\n{error}", parent=self.root)

    def edit_selected(self):
        selected = self.transaction_tree.selection()
        if not selected:
            messagebox.showinfo("Select an expense", "Choose a transaction to edit.", parent=self.root)
            return
        expense_id = int(self.transaction_tree.item(selected[0], "values")[0])
        expense = self.db.get_expense(expense_id)
        if expense:
            ExpenseDialog(self.root, self.save_expense, expense)

    def delete_selected(self):
        selected = self.transaction_tree.selection()
        if not selected:
            messagebox.showinfo("Select an expense", "Choose a transaction to delete.", parent=self.root)
            return
        expense_id = int(self.transaction_tree.item(selected[0], "values")[0])
        if messagebox.askyesno("Confirm deletion", "Delete the selected expense? This cannot be undone.", parent=self.root):
            self.db.delete_expense(expense_id)
            self.refresh_all()

    def clear_filters(self):
        self.filter_month_var.set("")
        self.filter_category_var.set("All Categories")
        self.search_var.set("")
        self.refresh_transactions()

    def export_csv(self):
        month = self.filter_month_var.get().strip()
        if month:
            try:
                datetime.strptime(month, "%Y-%m")
            except ValueError:
                messagebox.showerror("Invalid month", "Enter the month as YYYY-MM, or leave it blank.", parent=self.root)
                return
        rows = self.db.get_expenses(month, self.filter_category_var.get(), self.search_var.get().strip())
        if not rows:
            messagebox.showinfo("Nothing to export", "There are no transactions matching the current filters.", parent=self.root)
            return
        filename = filedialog.asksaveasfilename(
            parent=self.root, defaultextension=".csv", filetypes=[("CSV files", "*.csv")],
            initialfile="expenses_export.csv"
        )
        if not filename:
            return
        try:
            with open(filename, "w", newline="", encoding="utf-8-sig") as file:
                writer = csv.writer(file)
                writer.writerow(["ID", "Date", "Category", "Description", "Amount", "Payment Method"])
                for row in rows:
                    writer.writerow([row["id"], row["expense_date"], row["category"],
                                     row["description"], row["amount"], row["payment_method"]])
            messagebox.showinfo("Export complete", f"Exported {len(rows)} transaction(s) to CSV.", parent=self.root)
        except OSError as error:
            messagebox.showerror("Export failed", str(error), parent=self.root)

    def save_budget(self):
        month = self.budget_month_var.get().strip()
        try:
            datetime.strptime(month, "%Y-%m")
        except ValueError:
            messagebox.showerror("Invalid month", "Enter the month as YYYY-MM.", parent=self.root)
            return
        try:
            amount = float(self.budget_amount_var.get().strip())
            if amount <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid amount", "Enter a budget amount greater than zero.", parent=self.root)
            return
        self.db.save_budget(month, self.budget_category_var.get(), amount)
        self.budget_amount_var.set("")
        self.refresh_budgets()
        self.refresh_dashboard()
        messagebox.showinfo("Budget saved", "The category budget has been saved.", parent=self.root)

    def delete_selected_budget(self):
        selected = self.budget_tree.selection()
        if not selected:
            messagebox.showinfo("Select a budget", "Choose a budget to delete.", parent=self.root)
            return
        budget_id = int(self.budget_tree.item(selected[0], "values")[0])
        if messagebox.askyesno("Confirm deletion", "Delete this budget allocation?", parent=self.root):
            self.db.delete_budget(budget_id)
            self.refresh_budgets()
            self.refresh_dashboard()

    def close_app(self):
        self.db.close()
        self.root.destroy()


def main():
    root = tk.Tk()
    ExpenseManagerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
