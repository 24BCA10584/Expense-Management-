EXPENSE MANAGEMENT SYSTEM
=========================

A desktop expense tracker made with Python, Tkinter and SQLite.

FEATURES
--------
1. Add, edit and delete expenses.
2. Store expense date, category, description, amount and payment method.
3. View a dashboard with monthly spending, budget, remaining budget and transaction count.
4. View category-wise spending and a six-month spending trend.
5. Search and filter transactions by month, category and description.
6. Set monthly budgets for individual categories.
7. Export filtered transactions to a CSV file.
8. Save data locally in expense_manager.db.

REQUIREMENTS
------------
- Python 3.10 or later is recommended.
- Tkinter (usually included with the standard Python installation).
- No third-party Python packages are required.

HOW TO RUN ON WINDOWS
--------------------
1. Extract the project folder.
2. Double-click run_expense_manager.bat.

Alternatively, open Command Prompt in this folder and run:
    py expense_manager.py

HOW TO USE
----------
1. Open the Dashboard to view monthly spending and recent transactions.
2. Open Transactions and click Add Expense to record a purchase or payment.
3. Select a transaction and use Edit selected or Delete selected to manage it.
4. Use the month, category and search filters to find records.
5. Click Export CSV to save the currently filtered transactions.
6. Open Monthly Budgets, enter a month in YYYY-MM format (for example, 2026-11),
   choose a category, enter the budget and click Save budget.

DATA STORAGE
------------
The application creates expense_manager.db automatically in the same folder as
expense_manager.py. Keep this database file to retain your expenses and budgets.
